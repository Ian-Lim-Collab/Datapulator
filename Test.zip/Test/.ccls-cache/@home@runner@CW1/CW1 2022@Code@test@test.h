#include <iostream>

class test
{
private:
    /* data */
public:
    test(/* args */);
   
};

