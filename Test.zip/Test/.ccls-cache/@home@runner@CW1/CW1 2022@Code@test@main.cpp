#include"test.h"
#include <iostream>

using namespace std;

int main(void){
    cout << "hello1\n";
    test t1;
}
