class test{
  public:
  test(int a);
};

class test1:public test{
  test1(int a);
}