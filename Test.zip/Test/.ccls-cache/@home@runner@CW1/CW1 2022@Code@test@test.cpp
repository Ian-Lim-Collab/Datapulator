#include "test.h"
#include <iostream>

test::test(/* args */)
{
    cout << "hello2\n";
}

